gmx_mpi grompp -f st.mdp -c em.gro -r em.gro -p topol.top -n 1index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 

