The PDB coordinates of Myosin-V Postrigor and Prepowerstroke state has been taken from 1w7j.pdb and 4zg4.pdb respectively. The PDB coordinates of Myosin-VI Postrigor and Prepowerstroke state has been taken from 2vb6.pdb and 2v26.pdb respectively. These coordinates have been deposited inside the "pdb coodinates" folder. 
 
The TAPS simulation coordinate file and sample files are attached inside "TAPS-Myosin-sample folder".

The script to run renormalization is inside "Renormalisation_sample_file" folder. It can be executed as "./channelix21vel.exe_xyz < gramicidin.inp > a.log &

The sample input coordinates and input topologies and parameters for Steer molecular dynamics simulations and Umbrella sampling simulations are attached inside the "Steer_sample_file and "Umbrella_sample_file" respectively. All the related force-filed parameters are included inside the charmm36-jul2022.ff folder.